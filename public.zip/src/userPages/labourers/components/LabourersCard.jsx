import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router';
import { FullpricesUrl } from '../../../../fetchers/URL_SERVER';
import { GetData } from '../../../../fetchers/CRUD';

const LabourersCard = () => {
  const [prices, setPrices] = useState([])
  const { id } = useParams();
  useEffect(() => {
    const handleData = (data, status) => {
      if (status === 200) {
        setPrices(data);
      } else {
        console.error("Ошибка загрузки данных:", status);
      }
    };
    
    GetData(FullpricesUrl, handleData);
  }, []);
  const currentService = prices.find((item) => item.id === Number(id))
  console.log(prices);
  
  console.log(currentService);
  
  return (
    <div>LabourersCard {currentService?.name || 'Загрузка...'} </div>
  )
}

export default LabourersCard